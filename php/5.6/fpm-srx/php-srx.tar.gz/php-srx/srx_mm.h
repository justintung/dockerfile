#ifndef __SRX_MM_H
#define __SRX_MM_H

int srx_mm_init(int block_size);
void *srx_mm_malloc(int size);
void *srx_mm_calloc(int size);
void srx_mm_free(void *p);
void srx_mm_flush();
int srx_mm_availspace();
int srx_mm_realspace();
void srx_mm_destroy();

void srx_mm_lock();
void srx_mm_unlock();

#endif
