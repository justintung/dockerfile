#ifndef SRX_LOG_H
#define SRX_LOG_H

#ifdef PHP_WIN32
#include "win95nt.h"
#else
#include <unistd.h>
#endif

typedef enum {
    srx_log_debug,  /* 0 */
    srx_log_notice, /* 1 */
    srx_log_error   /* 2 */
} srx_log_level;

int srx_log_init(char *log_file, int level);
int srx_log_chown(uid_t uid, gid_t gid);
void srx_write_log(srx_log_level level, const char *fmt, ...);
void srx_log_destroy();

#endif
