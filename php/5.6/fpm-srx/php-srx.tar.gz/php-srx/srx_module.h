#ifndef __SRX_MODULE_H
#define __SRX_MODULE_H

typedef int srx_encrypt_op_t(char *inbuf, int inlen,
    char **outbuf, int *outlen);
typedef int srx_decrypt_op_t(char *inbuf, int inlen,
    char **outbuf, int *outlen);
typedef void srx_free_buf_t(void *buf);

typedef enum {
  SRX_ENCRYPT_TYPE_DES = 1,
  SRX_ENCRYPT_TYPE_AES,
  SRX_ENCRYPT_TYPE_BASE64,
  SRX_ENCRYPT_TYPE_ERROR
} srx_encrypt_type_t;

struct srx_ops {
    char *name;
    srx_encrypt_op_t *encrypt;
    srx_decrypt_op_t *decrypt;
    srx_free_buf_t *free;
    struct srx_ops *next;
};

#endif
