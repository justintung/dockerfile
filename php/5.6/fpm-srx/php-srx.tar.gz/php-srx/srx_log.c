#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#ifdef PHP_WIN32

#else
#include <unistd.h>
#endif
#include "main/php_reentrancy.h"
#include "srx_log.h"

static FILE *srx_log_fp = NULL;
static int log_level = srx_log_notice;

int srx_log_init(char *log_file, int level)
{
    if (!log_file || strlen(log_file) == 0) {
        return 0;
    }

    srx_log_fp = fopen(log_file, "a+");
    if (!srx_log_fp)
        return -1;
    log_level = level;
    return 0;
}


int srx_log_chown(uid_t uid, gid_t gid)
{
#ifdef PHP_WIN32
	return 1;
#else
    int fd;

    if (!srx_log_fp) {
        return 0;
    }

    fd = fileno(srx_log_fp);

    return fchown(fd, uid, gid);
#endif
}


void srx_write_log(srx_log_level level, const char *fmt, ...)
{

    struct tm local_tm, *result_tm;
    time_t the_time;
    char buf[64];
    char *headers[] = {"DEBUG", "NOTICE", "ERROR"};
    va_list ap;

    if (srx_log_fp == NULL ||
        level > srx_log_error ||
        level < log_level)
    {
        return;
    }

    va_start(ap, fmt);

    the_time = time(NULL);
    result_tm = php_localtime_r(&the_time, &local_tm);
    strftime(buf, 64, "%d %b %H:%M:%S", result_tm);

    fprintf(srx_log_fp, "[%s] %s: ", buf, headers[level]);
    vfprintf(srx_log_fp, fmt, ap);
    fprintf(srx_log_fp, "\n");
    fflush(srx_log_fp);

    va_end(ap);

    return;
}

void srx_log_destroy()
{
    if (srx_log_fp) {
        fclose(srx_log_fp);
        srx_log_fp = NULL;
    }
}
