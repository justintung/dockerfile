/*
  +----------------------------------------------------------------------+
  | PHP Version 5                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2007 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: Liexusong <liexusong@qq.com>                                 |
  +----------------------------------------------------------------------+
*/

/*
 * The simple share memory manager algorithm
 */

#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <fcntl.h>
#include <sys/types.h>
#ifdef PHP_WIN32
#include <Windows.h>
#else
#include <sys/mman.h>
#endif

#include "spinlock.h"
#include "srx_log.h"
#include "shm.h"

#define SRX_SEGMENT_DEFAULT_SIZE (256 * 1024)

#define BLOCKAT(addr, offset)  ((srx_block_t *)((char *)(addr) + (offset)))

#ifdef max
#undef max
#endif
#define max(a, b) ((a) > (b) ? (a) : (b))

typedef struct srx_header_s {
    int segsize;    /* size of entire segment */
    int avail;      /* bytes available memorys */
} srx_header_t;

typedef struct srx_block_s {
    int size;       /* size of this block */
    int next;       /* offset in segment of next free block */
} srx_block_t;

static int srx_mm_initialized = 0;
static void *srx_mm_block = NULL;
static int srx_mm_block_size = 0;
static srx_atomic_t *mm_lock;
extern int srx_pid;

void srx_mm_lock()
{
    srx_spinlock(mm_lock, srx_pid);
}

void srx_mm_unlock()
{
    srx_spinunlock(mm_lock, srx_pid);
}

/*
 * memory align function
 * @param bits, align bits
 */
static inline int srx_mm_alignmem(int bits)
{
    typedef union {
        void* p;
        int i;
        long l;
        double d;
        void (*f)();
    } srx_word_t; /* may be 8 bits */

    return sizeof(srx_word_t) * (1 + ((bits - 1) / sizeof(srx_word_t)));
}

static int srx_mm_allocate(void *shmaddr, int size)
{
    srx_header_t *header;       /* header of shared memory segment */
    srx_block_t *prv;           /* block prior to working block */
    srx_block_t *cur;           /* working block in list */
    srx_block_t *prvbestfit;    /* block before best fit */
    int realsize;                 /* actual size of block needed, including header */
    int minsize;                  /* for finding best fit */
    int offset;

    /* Realsize must be aligned to a word boundary on some architectures. */
    realsize = size + srx_mm_alignmem(sizeof(int));
    realsize = srx_mm_alignmem(max(realsize, sizeof(srx_block_t)));

    /*
     * First, insure that the segment contains at least realsize free bytes,
     * even if they are not contiguous.
     */
    header = (srx_header_t *)shmaddr;
    if (header->avail < realsize) {
        srx_write_log(srx_log_error,
                        "Not enough memory for srx_mm_alloc()");
        return -1;
    }

    prvbestfit = 0;    /* Best block prev's node */
    minsize = INT_MAX;

    prv = BLOCKAT(shmaddr, sizeof(srx_header_t)); /* Free list header */

    while (prv->next != 0) {
        cur = BLOCKAT(shmaddr, prv->next); /* Current active block */
        if (cur->size == realsize) {
            prvbestfit = prv;
            break;
        }
        else if (cur->size > (sizeof(srx_block_t) + realsize)
                 && cur->size < minsize)
        {
            prvbestfit = prv;
            minsize = cur->size;
        }
        prv = cur;
    }

    if (prvbestfit == 0) { /* Not found best block */
        return -1;
    }

    prv = prvbestfit;
    cur = BLOCKAT(shmaddr, prv->next);

    /* update the block header */
    header->avail -= realsize;

    if (cur->size == realsize) {
        prv->next = cur->next;

    } else {
        srx_block_t *nxt;   /* The new block (chopped part of cur) */
        int nxtoffset;        /* Offset of the block currently after cur */
        int oldsize;          /* Size of cur before split */

        /* bestfit is too big; split it into two smaller blocks */
        nxtoffset = cur->next;
        oldsize = cur->size;
        prv->next += realsize;
        cur->size = realsize;
        nxt = BLOCKAT(shmaddr, prv->next);
        nxt->next = nxtoffset;
        nxt->size = oldsize - realsize;
    }

    /* skip size field */

    offset = (char *)cur - (char *)shmaddr;

    return offset + srx_mm_alignmem(sizeof(int));
}

static int srx_mm_deallocate(void *shmaddr, int offset)
{
    srx_header_t *header;   /* Header of shared memory segment */
    srx_block_t *cur;       /* The new block to insert */
    srx_block_t *prv;       /* The block before cur */
    srx_block_t *nxt;       /* The block after cur */
    int size;                 /* Size of deallocated block */

    offset -= srx_mm_alignmem(sizeof(int)); /* Really offset */

    /* Find position of new block in free list */
    prv = BLOCKAT(shmaddr, sizeof(srx_header_t));

    while (prv->next != 0 && prv->next < offset) {
        prv = BLOCKAT(shmaddr, prv->next);
    }

    /* Insert new block after prv */
    cur = BLOCKAT(shmaddr, offset);
    cur->next = prv->next;
    prv->next = offset;

    /* Update the block header */
    header = (srx_header_t *)shmaddr;
    header->avail += cur->size;
    size = cur->size;

    if (((char *)prv) + prv->size == (char *) cur) {
        /* cur and prv share an edge, combine them */
        prv->size += cur->size;
        prv->next = cur->next;
        cur = prv;
    }

    nxt = BLOCKAT(shmaddr, cur->next);
    if (((char *)cur) + cur->size == (char *) nxt) {
        /* cur and nxt shared an edge, combine them */
        cur->size += nxt->size;
        cur->next = nxt->next;
    }

    return size;
}

void srx_mm_reinit()
{
    srx_header_t *header;
    srx_block_t  *block;

    header = (srx_header_t *)srx_mm_block;
    header->segsize = srx_mm_block_size;
    header->avail = srx_mm_block_size
                    - sizeof(srx_header_t)
                    - sizeof(srx_block_t)
                    - srx_mm_alignmem(sizeof(int));

    /* The free list head block node */
    block = BLOCKAT(srx_mm_block, sizeof(srx_header_t));
    block->size = 0;
    block->next = sizeof(srx_header_t) + sizeof(srx_block_t);

    /* The avail block */
    block = BLOCKAT(srx_mm_block, block->next);
    block->size = header->avail;
    block->next = 0;
}

/*
 * Init memory manager
 */
int srx_mm_init(int block_size)
{
    if (srx_mm_initialized) {
        return 0;
    }

    /* Init memory manager lock */
    mm_lock = (int *)srx_shm_alloc(sizeof(srx_atomic_t));
    if (!mm_lock) {
        srx_write_log(srx_log_error,
                        "Unable alloc share memory for memory manager lock");
        return -1;
    }

    *mm_lock = 0;

    /* Init share memory for srx */
    if (block_size < SRX_SEGMENT_DEFAULT_SIZE) {
        srx_mm_block_size = SRX_SEGMENT_DEFAULT_SIZE;
    } else {
        srx_mm_block_size = block_size;
    }

    srx_mm_block = (void *)srx_shm_alloc(srx_mm_block_size);
    if (!srx_mm_block) {
        srx_write_log(srx_log_error,
                        "Unable alloc share memory for srx");
        srx_shm_free((void *)mm_lock, sizeof(srx_atomic_t));
        return -1;
    }

    srx_mm_reinit();

    srx_mm_initialized = 1;

    return 0;
}

void *srx_mm_malloc(int size)
{
    int offset;
    void *p = NULL;

    srx_mm_lock();

    offset = srx_mm_allocate(srx_mm_block, size);
    if (offset != -1) {
        p = (void *)(((char *)srx_mm_block) + offset);
    }

    srx_mm_unlock();

    return p;
}

void *srx_mm_calloc(int size)
{
    int offset;
    void *p = NULL;

    srx_mm_lock();

    offset = srx_mm_allocate(srx_mm_block, size);
    if (offset != -1) {
        p = (void *)(((char *)srx_mm_block) + offset);
    }

    srx_mm_unlock();

    if (NULL != p) {
        memset(p, 0, size);
    }

    return p;
}

void srx_mm_free(void *p)
{
    int offset;

    offset = (unsigned int)((char *)p - (char *)srx_mm_block);
    if (offset <= 0) {
        return;
    }

    srx_mm_lock();
    srx_mm_deallocate(srx_mm_block, offset);
    srx_mm_unlock();
}

void srx_mm_flush()
{
    srx_mm_lock();
    srx_mm_reinit();
    srx_mm_unlock();
}

/*
 * Get the avail's memory space
 */
int srx_mm_availspace()
{
    int size;
    srx_header_t *header = (srx_header_t *)srx_mm_block;

    srx_mm_lock();
    size = header->avail;
    srx_mm_unlock();

    return size;
}

/*
 * Don't locked here, because the segsize not change forever
 */
int srx_mm_realspace()
{
    int size;

    srx_mm_lock();
    size = ((srx_header_t *)srx_mm_block)->segsize;
    srx_mm_unlock();

    return size;
}

/*
 * Destroy memory's manager
 */
void srx_mm_destroy()
{
    if (srx_mm_initialized) {
        srx_shm_free((void *)srx_mm_block, srx_mm_block_size);
        srx_shm_free((void *)mm_lock, sizeof(srx_atomic_t));
        srx_mm_initialized = 0;
    }
}
