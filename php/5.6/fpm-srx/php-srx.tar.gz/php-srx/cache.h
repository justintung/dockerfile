#ifndef __SRX_CACHE_H
#define __SRX_CACHE_H

typedef struct cache_key_s {
    int device;
    int inode;
    int mtime;
    int fsize;
} cache_key_t;


typedef struct cache_item_s {
    cache_key_t key;
    struct cache_item_s *next;
    char data[0];
} cache_item_t;


#define srx_cache_data(item)  (item)->data
#define srx_cache_size(item)  (item)->key.fsize

int srx_cache_init();
cache_item_t *srx_cache_find(cache_key_t *key);
cache_item_t *srx_cache_create(cache_key_t *key);
cache_item_t *srx_cache_push(cache_item_t *item);
int srx_cache_destroy();
void srx_cache_flush();

void srx_cache_lock();
void srx_cache_unlock();
void srx_cache_info(zval *);

#endif
