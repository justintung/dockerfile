#ifndef __SRX_SPINLOCK_H
#define __SRX_SPINLOCK_H

typedef volatile unsigned int srx_atomic_t;

void srx_spinlock(srx_atomic_t *lock, int pid);
void srx_spinunlock(srx_atomic_t *lock, int pid);

#endif
