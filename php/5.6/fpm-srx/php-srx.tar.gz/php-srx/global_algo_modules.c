#include <stdlib.h>
#include "srx_module.h"

extern struct srx_ops des_handler_ops;
extern struct srx_ops aes_handler_ops;
extern struct srx_ops base64_handler_ops;

struct srx_ops *ops_handler_list[] = {
    &des_handler_ops,
    &aes_handler_ops,
    &base64_handler_ops,
    NULL,
};
